/*
 * Test_Cases.h
 *
 *  Created on: 15/11/2018
 *      Author: Omar Sevilla
 */

#ifndef TEST_TEST_CASES_H_
#define TEST_TEST_CASES_H_

/* Includes */
#include <Arduino.h>
#include "../application/app_LCD.h"

/* External Prototypes */
extern void Test_Case_LCD(void);


#endif /* TEST_TEST_CASES_H_ */
