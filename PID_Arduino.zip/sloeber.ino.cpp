#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2018-11-15 22:34:24

#include "Arduino.h"
#include "Arduino.h"
#include "application/app_LCD.h"
#define TEST_LCD
#include "test/Test_Cases.h"

void setup() ;
void loop() ;

#include "PID_Arduino.ino"


#endif
