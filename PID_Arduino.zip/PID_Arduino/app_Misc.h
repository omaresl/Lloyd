/*
 * app_Misc.h
 *
 *  Created on: 25 nov. 2018
 *      Author: Admin
 */

#ifndef APPLICATION_APP_MISC_H_
#define APPLICATION_APP_MISC_H_

/* Interfaces */

/* Public Type definitions */

/* Public Macros */

/* Public Variables */

/* Public Prototypes */
extern float app_Misc_FloatMax(float* lp_FloatArray, unsigned int lul_size);
extern float app_Misc_FloatMin(float* lp_FloatArray, unsigned int lul_size);


#endif /* APPLICATION_APP_MISC_H_ */
